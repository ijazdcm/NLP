
export const changeStateConstant = {
  set:"set"
}
