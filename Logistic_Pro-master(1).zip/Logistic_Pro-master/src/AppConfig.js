

const  AppConfig = {
  version:'1.0.0',
  api:{
      baseUrl: 'http://127.0.0.1:8000/api/v1'
  }
}

export default  AppConfig
