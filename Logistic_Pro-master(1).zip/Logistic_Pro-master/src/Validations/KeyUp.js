export default function keyUp(values) {
  if (values.vNum) {
    console.log(values.vNum.toUpperCase())
  }
}
