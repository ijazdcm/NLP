import React, { useEffect, useState } from 'react'
import { AppHeaderDropdown } from '.'

const Title = ({tittle}) => {


  return (
    <>
      <h3 className="text-info text-center">{tittle}</h3>
    </>
  )
}

export default Title
